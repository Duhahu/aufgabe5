package de.hfu.residents.service;

/**
 * @author Stefan Betermieux
 */
public class ResidentServiceException extends Exception {

  /**
   * @param message
   */
  public ResidentServiceException(String message) {
    super(message);
  }

}
